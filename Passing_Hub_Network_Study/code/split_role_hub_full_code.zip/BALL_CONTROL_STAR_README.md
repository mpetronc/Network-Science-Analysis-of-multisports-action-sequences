Active star rule: highest prior-season touches, possession time breaks ties

Primary metric is total 2024-25 TOUCHES, not per-minute or per-game rates. Eligibility ≥1,000 tracked minutes. Break exact ties with greater total TIME_OF_POSS, then lower PLAYER_ID. No combined score is used. The raw measures and all eligible ranks are exported.

Download/rebuild: python3 teamgraphs.py --ball-control-dependency --download
Saved season analysis: python3 teamgraphs.py --ball-control-dependency
Three-panel graphs: python3 teamgraphs.py --ball-control-removed-networks
Pre-absence forecast: python3 teamgraphs.py --ball-control-forecast

Default output: nba_passing_output/ball_control_dependency. Existing player/team logs, historical rosters, complete passing matrices and official on/off tables remain prerequisites. The generic prospective_absence module retains its on/off defaults; the ball-control wrapper explicitly supplies the touches-selected stars. Earlier analyses and commands remain unchanged. Active definition is recorded in ACTIVE_STAR_DEFINITION.json.
