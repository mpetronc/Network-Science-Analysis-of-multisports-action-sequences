Original / deleted-star baseline / actual missed-game networks

Run: python3 teamgraphs.py --predicted-actual-networks
Refresh statistics only: python3 teamgraphs.py --predicted-actual-networks --skip-network-plots
Verify: python3 verify_predicted_actual.py --data-dir nba_passing_output/onoff_dependency/predicted_actual_networks

Uses the original prior-season on/off-selected players and already validated played/missed networks from nba_passing_output/onoff_dependency. All 30 are illustrated; only the existing 24 teams with ≥15 played and ≥10 missed games enter the fit. Node area is proportional to its own graph’s passes-in-plus-out involvement share, on a common area scale. Edges use context-normalized passes and fixed within-team width scale; positions fixed. Isolates omitted. Full CSVs retain every player and positive edge. See METHOD_AND_RESULTS.md and COMPARISON_AND_INTERPRETATION.md for interpretation and limitations.
