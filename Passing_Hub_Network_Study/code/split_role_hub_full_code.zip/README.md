# Whole-season passing networks with three FGA endpoints

Complete updated teamgraphs.py and its existing companion modules. Put these files together in SportsAnalysis. Existing commands remain available.

New command:

    python3 teamgraphs.py --fg-attempt-networks

One team-season:

    python3 teamgraphs.py --fg-attempt-networks --season 2021-22 --team GSW

Inputs: existing nba_passing_output/full_roster_entropy_centrality/historical_full_rosters/SEASON/TEAM/{passing_matrix.csv,roster.csv}; and nba_passing_output/shot_attempt_cache/SEASON_shot_attempts.csv.gz. The installed Desktop project includes both. Downloads can be recreated with:

    python3 fetch_shot_attempts.py

The league-wide shot endpoint can silently truncate; the downloader uses 30 team requests per season. Requires nba_api, numpy, pandas, matplotlib and networkx (same environment as the existing project). Raw caches/older analysis data are not included in this code-only archive.

The three shot endpoints are Mid-range / other 2PT, 3PT, and Layup / dunk. Makes and misses included. First classify all threes; for twos, use action descriptions containing layup or dunk; all remaining twos go to other 2PT. Thus hooks, floaters and tip-ins remain represented without falsely calling them strict mid-range shots. Strict NBA Mid-Range counts are exported separately.

All original passes unchanged; player layout is Fruchterman–Reingold from passing edges only. Original player nodes are retained; true isolates are hidden in the drawing. No minutes cutoff. Shot-edge weights = team passes × player/category FGA ÷ team FGA. Combined shot edges equal total passes. Raw shot counts are preserved. There are no inbound, rebound, steal, foul, turnover or free-throw nodes, and no outgoing shot-node edges.

Player FGA, 3PA, FGM and 3PM must match original team-season totals exactly. Missing/invalid/incomplete data causes an error rather than being silently treated as zero. These are season aggregates, not actual reconstructed passing sequences ending in shots. Previous outputs are preserved in their folders.

New results: nba_passing_output/fg_attempt_networks/all_fg_attempt_networks.pdf, individual SEASON/TEAM/network.png and network.pdf, player_shot_counts.csv, edges.csv, GraphML, validation.csv and source_manifest.csv.

Entropy vs star concentration: python3 teamgraphs.py --star-entropy-regressions
Results include overall and per-season scatterplots, robust regressions, scaling sensitivities and source hashes. See generated entropy_star_regressions/README.md for definitions and interpretation.

Combined centrality + usage entropy regression: python3 teamgraphs.py --combined-star-entropy. Requires the saved original usage_starness profiles and entropy_star_regressions metrics. Uses frozen equal-weight percentile index.

Team-specific pass/FGA weighting: python3 teamgraphs.py --action-weighted-star-entropy. Uses raw passes/(passes+FGA) for centrality and FGA/(passes+FGA) for usage, with the same frozen component percentiles. Entropy definitions remain unchanged to isolate the index-weight change.

Actual-count entropy correction: python3 teamgraphs.py --raw-count-star-entropy. Uses raw pass and FGA counts for entropy and unchanged team-specific action-weighted starness. Before/after regression CSV and per-season graphs included in the generated result folder. Previous graph drawings remain untouched.

Separated structure/leader/absence analyses: python3 teamgraphs.py --structure-validation. Independent volume-based null: python3 passing_null_test.py. Both reuse saved SportsAnalysis inputs. Null holds outgoing counts exact and incoming counts in expectation, with no self-passes. 500 independent draws/team. See result ANALYSIS.md for findings and limitations.

Four metric pairwise regressions: python3 teamgraphs.py --four-metric-regressions. Reads original full-roster passing matrices, roster totals and raw shot-type edges. Produces all six pairs overall/per season, corrections, sensitivities, definitions and source hashes.

NBA court-zone networks: python3 teamgraphs.py --court-zone-networks [--season 2021-22 --team GSW]. Court-zone entropy regressions: python3 teamgraphs.py --court-zone-regressions. Uses cached original NBA shot-zone labels (14 half-court plus backcourt), raw passes/FGA counts. EC still uses only original passing edges. New results in nba_passing_output/court_zone_networks, leaving previous three-category results unchanged.

Verify all 180 court-zone graph sets: python3 verify_court_zones.py nba_passing_output/court_zone_networks. Court-zone screenshots include per-team court_zone_map.png and network.png; combined all_court_zone_networks.pdf has 180 pages.

Revised measurement and validation: python3 teamgraphs.py --revised-methodology. Requires the existing SportsAnalysis full-roster data, court-zone count exports, stored independent passing-null data and position metadata. It preserves prior outputs; writes court_zone_networks/revised_methodology with new_data.csv, METHODOLOGY.md, RESULTS.md, graph PDFs and all sensitivity tables. Verify with python3 verify_revised_methodology.py nba_passing_output/court_zone_networks/revised_methodology. Read the opportunity sensitivities and retrospective-validation limits before interpreting strong correlations.

Five-season prior-defined leader absence study: python3 teamgraphs.py --star-dependency-study. Official game-cache downloader: python3 fetch_dependency_games.py. Inputs are existing full-roster prior networks/court-zone and revised metrics, saved shot caches, and the new complete six-season game cache. Outputs star_dependency_study includes methodology, results, performance graphs, episode adaptation, QC exclusions, sensitivity models and raw/compressed panels. Verify with python3 verify_star_dependency.py nba_passing_output/star_dependency_study. Estimates are observational nonappearance penalties, not confirmed injury or on/off-court causal player effects.

Contrasting network case studies: python3 teamgraphs.py --dependency-network-cases. All nine available 2025–26 matched passing-hub contexts; six outcome-ranked illustrations highlighted and all nine shown. Outputs include an 11-page PDF, per-team PNGs/matched matrices, role changes with minutes/FGA shares, uncertainty/equivalence diagnostics and the separate full-92 performance ranking. No new causal regression on selected extremes is claimed.

Full-network entropy with and without the hub: python3 teamgraphs.py --star-presence-entropy. Includes the star in the present network, actual full absent network, synthetic deletion diagnostic, fixed within-team normalization, raw bits and equal-total-pass sensitivity. Preserves the earlier matched nonhub comparison separately.
