Frozen pre-absence two-game prediction pilot

Run: python3 teamgraphs.py --prospective-absence
Skip network graphics: python3 teamgraphs.py --prospective-absence --skip-network-plots
Verify: python3 verify_prospective_absence.py --output-dir nba_passing_output --data-dir nba_passing_output/onoff_dependency/prospective_absence

Requires previous onoff_dependency/selected_stars.csv, 2025-26 player/team logs, daily passing files and the project’s NBA API helper functions. Uses cached profiles when present. Downloads pre-window passing, freezes predictions, then downloads target passing. Target-game minutes/passing are never features of the frozen model. Actual-minutes benchmark is labelled outcome-known. Existing CLI and analyses are preserved. Read METHOD_AND_RESULTS.md and INTERPRETATION.md for the fixed episode rule, shrinkage, caps, held-out scores and limitations.
