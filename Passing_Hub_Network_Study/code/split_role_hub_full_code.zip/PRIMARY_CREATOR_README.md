Active star definition: previous-season primary creator

Creator = highest 2024-25 POTENTIAL_AST per36 among player-team stints with at least 1,000 tracked minutes. Rate = 36 * POTENTIAL_AST / tracking MIN. Exact ties use lowest player ID. No substitute is selected when the strict prior leader is unavailable for a valid comparison. All 30 winners and all candidates are retained.

Download/rebuild: python3 teamgraphs.py --creator-dependency --download
Rerun saved season analysis: python3 teamgraphs.py --creator-dependency
Redraw three panels: python3 teamgraphs.py --creator-removed-networks
Frozen pre-absence pilot: python3 teamgraphs.py --creator-forecast

The forecast uses the same prespecified baseline, rotation-history, shrinkage, cap and two-game evaluation rules as the earlier pilot. The generic prospective_absence module now accepts --star-source and --star-definition while retaining its earlier on/off defaults. Creator command passes the new selection explicitly.

Existing raw game logs, full-season passing matrices, official on/off tables and exact-match cached partitions from earlier project work remain prerequisites. Results and source data default to nba_passing_output/creator_dependency. Older studies and CLI remain reproducible as alternative definitions. The preferred current definition is stored in ACTIVE_STAR_DEFINITION.json.
