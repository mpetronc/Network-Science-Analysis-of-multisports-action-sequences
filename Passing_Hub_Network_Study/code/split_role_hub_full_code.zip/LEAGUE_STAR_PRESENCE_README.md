2025–26 all-team descriptive passing-hub entropy comparison

Run from SportsAnalysis:
python3 fetch_league_absence_networks.py
python3 teamgraphs.py --league-star-presence-entropy

Requires original project source data and validated cached networks. Results bundle includes the six new reconstructed partitions and downloaded profiles. Prior 21 cached partitions remain in the original project. Hub = current full-season passing-only EC leader. Earlier studies and commands are preserved. See RESULTS_AND_METHOD.md for definitions and limitations.
