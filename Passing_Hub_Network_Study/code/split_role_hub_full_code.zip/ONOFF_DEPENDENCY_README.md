On/off-selected dependency analysis, 2025–26

Run from SportsAnalysis:
python3 teamgraphs.py --onoff-dependency --download

To rerun saved data without downloading:
python3 teamgraphs.py --onoff-dependency

To redraw only the three network panels:
python3 teamgraphs.py --onoff-star-networks

Sources and outputs default to nba_passing_output/onoff_dependency. Optional --output-dir and --data-dir are supported. Original game logs, full-season passing matrices and prior validated caches remain project prerequisites. The results archive contains the newly downloaded on/off tables, passing profiles, audits, reconstructed networks and figures. See METHOD_AND_RESULTS.md for player eligibility, prior-season ranking, trade windows, on/off versus played/missed distinctions and uncertainty.
