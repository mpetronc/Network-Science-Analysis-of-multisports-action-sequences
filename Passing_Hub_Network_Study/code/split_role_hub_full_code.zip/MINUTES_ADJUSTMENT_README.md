Steps 1–3: deletion baseline, recorded-minutes diagnostic, common-player analysis

Run: python3 teamgraphs.py --minutes-adjusted-networks
Statistics only: python3 teamgraphs.py --minutes-adjusted-networks --skip-network-plots
Verify: python3 verify_minutes_adjustment.py --output-dir nba_passing_output --data-dir nba_passing_output/onoff_dependency/minutes_adjustment

Requires previously saved onoff_dependency/predicted_actual_networks, game_comparison_data.csv and 2025-26 player game logs. No API download required. Uses actual recorded missed-game minutes as diagnostic inputs; this is not a prospective minutes allocation. Output defaults to nba_passing_output/onoff_dependency/minutes_adjustment. All 30 have pages; same 24 qualify for primary summaries. Previous commands and studies remain unchanged.
