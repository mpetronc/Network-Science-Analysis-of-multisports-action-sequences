EC-selected dependency comparison

Run: python3 teamgraphs.py --ec-player-dependency --download
Rerun saved data: python3 teamgraphs.py --ec-player-dependency
Redraw networks: python3 teamgraphs.py --ec-removed-networks

Sources default to nba_passing_output/ec_selected_dependency. Existing game logs, on/off tables from the prior onoff_dependency study, complete full-season networks and exact-match cached partitions are prerequisites. Strict prior-season EC leader, no fallback replacement. See coverage_all_30.csv. Main graph X is the prior on/off ORtg gap of the EC-selected player, not EC concentration. The results include actual absence plus explicitly synthetic deletion checks.
