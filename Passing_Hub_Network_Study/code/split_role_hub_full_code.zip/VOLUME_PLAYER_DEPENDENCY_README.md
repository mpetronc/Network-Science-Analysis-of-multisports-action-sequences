Star selection by total passes sent plus received

Definition: select argmax_i (row_sum_i + column_sum_i) from the 2024–25 passing matrix. Totals, not rates; passing edges only. Lowest player ID breaks exact ties. Prior-year choice preserves temporal separation from the 2025–26 response. No substitute if the leader fails the existing retained-first-ten check. All 30 winners and player-level rankings are exported, including unavailable comparisons.

Run: python3 teamgraphs.py --volume-player-dependency --download
Rerun saved matrices: python3 teamgraphs.py --volume-player-dependency
Redraw three panels: python3 teamgraphs.py --volume-removed-networks

Default folder: nba_passing_output/volume_selected_dependency. Existing full-season matrices, game logs, official on/off tables and exact cached partitions from prior studies remain prerequisites. The X-axis remains the selected player’s previous-season on/off ORtg gap. Played/missed and synthetic removal outputs are separate. Earlier analyses are preserved.
